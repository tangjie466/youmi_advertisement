## 导入项目注意事项

1. 导入Android项目到Eclipse中，然后按照文档章节—— **生成给Unity3d使用的jar** ，生成jar  
2. 导入Unity3d项目之后需要重新导入Android相关资源，具体做法参照文档章节—— **导入Android项目相关资源**  