package com.youmi.android.unity3d.demo;

import net.youmi.android.AdManager;
import net.youmi.android.banner.AdSize;
import net.youmi.android.banner.AdView;
import net.youmi.android.banner.AdViewListener;
import net.youmi.android.listener.Interface_ActivityListener;
import net.youmi.android.offers.OffersManager;
import net.youmi.android.offers.OffersWallDialogListener;
import net.youmi.android.offers.PointsChangeNotify;
import net.youmi.android.offers.PointsManager;
import net.youmi.android.spot.SpotDialogListener;
import net.youmi.android.spot.SpotManager;
import net.youmi.android.video.VideoAdManager;
import net.youmi.android.video.listener.VideoAdListener;
import net.youmi.android.video.listener.VideoAdRequestListener;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.unity3d.player.UnityPlayer;
import com.unity3d.player.UnityPlayerActivity;

public class MainActivity extends UnityPlayerActivity implements PointsChangeNotify {

	/**
	 * 无积分Banner
	 */
	AdView mAdView;

	/**
	 * Handler，用于线程与UI交互
	 */
	Handler mHandler;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mHandler = new Handler();

		// 初始化接口，应用启动的时候调用，参数：appId, appSecret, 是否开启调试模式
		AdManager.getInstance(this).init("9b26c34dca959658", "f5821b6374083845", false);

		// (可选)开启用户数据统计服务,(sdk v4.08之后新增功能)默认不开启，传入false值也不开启，只有传入true才会调用
		AdManager.getInstance(this).setUserDataCollect(true);

		// --------------------------------------------------------------------------------
		// 积分广告初始化及相关设置
		// 如果使用积分广告，请务必调用积分广告的初始化接口:
		OffersManager.getInstance(this).onAppLaunch();

		// （可选）注册积分监听-随时随地获得积分的变动情况
		PointsManager.getInstance(this).registerNotify(this);

		// --------------------------------------------------------------------------------
		// 插屏接口初始化及相关设置
		// （建议使用）预加载插播资源
		SpotManager.getInstance(this).loadSpotAds();

		// (可选) 设置插屏图片为竖屏
		SpotManager.getInstance(this).setSpotOrientation(
				SpotManager.ORIENTATION_PORTRAIT);

		// (可选) 设置插屏广告动画效果为高级动画效果
		SpotManager.getInstance(this).setAnimationType(SpotManager.ANIM_ADVANCE);

		// --------------------------------------------------------------------------------
		// 视频广告接口初始化及相关设置
		// （建议使用）预加载视频数据
		// 视频设置，提供视频的各种设置,如设置退出提示语，更改退出按钮，加载中的logo。
		VideoAdManager.getInstance(this).getVideoAdSetting().setInterruptsTips("是否要退出视频");

		VideoAdManager.getInstance(this).requestVideoAd(new VideoAdRequestListener() {

			@Override
			public void onRequestSucceed() {
				Log.d("videoPlay", "请求成功");

			}

			@Override
			public void onRequestFail(int errorCode) {
				// 关于错误码的解读：-1为网络连接失败，请检查网络。-2007为无广告，-3312为该设备一天的播放次数已完,其他错误码一般为设备问题。
				Log.d("videoPlay", "请求失败，错误码为:" + errorCode);
			}

		});

	}

	@Override
	protected void onDestroy() {
		super.onDestroy();

		// （可选）注销积分监听
		// 如果在onCreate调用了PointsManager.getInstance(this).registerNotify(this)进行积分余额监听器注册，那这里必须得注销
		PointsManager.getInstance(this).unRegisterNotify(this);

		// 回收积分广告占用的资源
		OffersManager.getInstance(this).onAppExit();

		// 回收插屏广告占用的资源
		SpotManager.getInstance(this).onDestroy();
		super.onDestroy();
	}

	public void showVideo() {
		mHandler.post(new Runnable() {

			@Override
			public void run() {
				VideoAdManager.getInstance(MainActivity.this).showVideo(MainActivity.this,
						new VideoAdListener() {

							// 视频播放失败
							@Override
							public void onVideoPlayFail() {
								Log.d("videoPlay", "failed");
							}

							// 视频播放完成
							@Override
							public void onVideoPlayComplete() {
								Log.d("videoPlay", "complete");
								Toast.makeText(MainActivity.this, "您获得了1个金币的奖励", Toast.LENGTH_SHORT).show();
							}

							// 视频播放完成的记录向服务器发送是否成功
							@Override
							public void onVideoCallback(boolean callback) {
								// 视屏播放记录发送是否回调成功
								Log.d("videoPlay", "completeEffect:" + callback);
							}

							// 视频播放中途退出
							@Override
							public void onVideoPlayInterrupt() {
								Log.d("videoPlay", "interrupt");
								Toast.makeText(MainActivity.this, "视频未播放完成，无法获取奖励", Toast.LENGTH_SHORT).show();
							}

							@Override
							public void onDownloadComplete(String id) {
								// TODO Auto-generated method stub

							}

							@Override
							public void onNewApkDownloadStart() {
								// TODO Auto-generated method stub

							}

							@Override
							public void onVideoLoadComplete() {
								// TODO Auto-generated method stub

							}
						});
			}
		});
	}

	/**
	 * 调用无积分插播广告--可以在Unity3d中直接调用
	 */
	public void showSpot() {
		mHandler.post(new Runnable() {

			@Override
			public void run() {
				// 展示插屏广告，可以不调用loadSpot独立使用
				SpotManager.getInstance(MainActivity.this).showSpotAds(MainActivity.this,
						new SpotDialogListener() {

							@Override
							public void onShowSuccess() {
								showTipsInUiThread("插屏广告展示成功", Toast.LENGTH_SHORT);
							}

							@Override
							public void onShowFailed() {
								showTipsInUiThread("插屏广告展示失败\n原因请查看Logcat-tag:YoumiSdk", Toast.LENGTH_LONG);
							}

							@Override
							public void onSpotClosed() {
								showTipsInUiThread("插屏广告关闭了", Toast.LENGTH_SHORT);
							}

						});
			}
		});
	}

	/**
	 * 如果插屏广告展示时，需要通过按返回键来进行关闭插屏广告的话，就调用下面这个方法（可选）
	 * 
	 * @param type
	 *            0 表示按了返回键 <br>
	 *            1 标识按了home键
	 * @return true 插屏广告已经消失了<br>
	 *         false 插屏广告还没有消失
	 */
	public boolean closeSpot(int type) {

		if (type == 0) {
			if (!SpotManager.getInstance(this).disMiss()) {
				// 如果没有插屏广告在展示，就返回true，执行开发者的逻辑
				return true;
			} else {
				// 如果有插屏广告在展示，就返回false
				return false;
			}
		}
		if (type == 1) {
			// 按home键时，调用尝试关闭插屏广告的代码
			// 如果不调用此方法，则按home键的时候会出现图标无法显示的情况。
			SpotManager.getInstance(this).onStop();
			return true;
		}
		return true;
	}

	/**
	 * 实例化无积分Banner并且将其加入到游戏界面中 --可以在Unity3d中直接调用
	 */
	public void showBanner() {
		if (mAdView == null) {
			mHandler.post(new Runnable() {

				@Override
				public void run() {
					// 实例化广告条
					mAdView = new AdView(MainActivity.this, AdSize.FIT_SCREEN);
					mAdView.setAdListener(new AdViewListener() {

						@Override
						public void onSwitchedAd(AdView arg0) {
							showTipsInUiThread("广告条切换广告了", Toast.LENGTH_SHORT);
						}

						@Override
						public void onReceivedAd(AdView arg0) {
							showTipsInUiThread("广告条接收到广告了", Toast.LENGTH_SHORT);
						}

						@Override
						public void onFailedToReceivedAd(AdView arg0) {
							showTipsInUiThread("广告条展示失败", Toast.LENGTH_LONG);
						}
					});
					// 创建布局来承载广告条
					LinearLayout layout = new LinearLayout(MainActivity.this);
					layout.addView(mAdView, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT,
							LinearLayout.LayoutParams.WRAP_CONTENT));

					// 采用WindowManager来进行
					WindowManager mWindowManager = (WindowManager) MainActivity.this
							.getSystemService(Context.WINDOW_SERVICE);
					WindowManager.LayoutParams mWmParams = new WindowManager.LayoutParams();
					mWmParams.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
							| WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
					mWmParams.height = -2;
					mWmParams.width = -1;
					mWmParams.alpha = 1.0F;
					mWmParams.format = 1;
					mWmParams.gravity = Gravity.BOTTOM;
					mWindowManager.addView(layout, mWmParams);

				}
			});
		}
	}

	/**
	 * 展示全屏积分墙--可以在Unity3d中直接调用
	 */
	public void showOffers() {
		mHandler.post(new Runnable() {

			@Override
			public void run() {
				OffersManager.getInstance(MainActivity.this).showOffersWall(
						new Interface_ActivityListener() {

							@Override
							public void onActivityDestroy(Context context) {
								// TODO Auto-generated method stub
								showTipsInUiThread("全屏积分墙退出了", Toast.LENGTH_LONG);
							}
						});
			}
		});
	}

	/**
	 * 展示对话框积分墙--可以在Unity3d中直接调用
	 */
	public void showOffersDialog() {
		mHandler.post(new Runnable() {

			@Override
			public void run() {
				OffersManager.getInstance(MainActivity.this).showOffersWallDialog(MainActivity.this,
						new OffersWallDialogListener() {

							@Override
							public void onDialogClose() {
								showTipsInUiThread("积分墙对话框关闭了", Toast.LENGTH_LONG);
							}
						});
			}
		});
	}

	/**
	 * 查询积分--可以在Unity3d中直接调用
	 * 
	 * @return
	 */
	public int queryPoints() {
		return PointsManager.getInstance(MainActivity.this).queryPoints();
	}

	/**
	 * 消费积分--可以在Unity3d中直接调用
	 * 
	 * @param p
	 * @return
	 */
	public boolean spendPoints(int p) {
		return PointsManager.getInstance(MainActivity.this).spendPoints(p);
	}

	/**
	 * 奖励积分(如用户完成了某个你觉得需要奖励他积分的操作时调用此接口进行奖励)--可以在Unity3d中直接调用
	 * 
	 * @param p
	 * @return
	 */
	public boolean awardPoints(int p) {
		return PointsManager.getInstance(MainActivity.this).awardPoints(p);
	}

	/**
	 * 积分余额变动通知，单用户的积分发生变动（增加或者减少）时，会回调本方法，本方法执行在UI线程中
	 */
	@Override
	public void onPointBalanceChange(int arg0) {
		// 当积分余额变动时，通知unity3d进行界面更新，
		// 参数1:发送游戏对象的名称
		// 参数2:对象绑定的脚本接收该消息的方法
		// 参数3:本条消息发送的字符串信息
		UnityPlayer.UnitySendMessage("Main Camera", "UpdatePoints", String.valueOf(arg0));
	}

	public void showTipsInUiThread(final String str, final int duartion) {
		mHandler.post(new Runnable() {

			@Override
			public void run() {
				Toast.makeText(MainActivity.this, str, duartion).show();
			}
		});
	}
}